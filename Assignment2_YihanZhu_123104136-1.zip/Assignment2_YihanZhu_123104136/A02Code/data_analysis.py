import pandas as pd
import json
import numpy as np

def create_dataframe(stats_file, probe_file):
    stats_data = json.load(open(stats_file))
    stats_raw = pd.json_normalize(stats_data['frames']) 
    stats_filtered = stats_raw[["frameNum", "metrics.psnr_hvs", "metrics.float_ssim", "metrics.vmaf"]]
    stats_filtered.columns = ["Number", "PSNR", "SSIM", "VMAF"]

    probe_data = json.load(open(probe_file))
    probe_raw = pd.json_normalize(probe_data['frames'])
    probe_filtered = probe_raw[["pkt_size", "pict_type", "coded_picture_number"]].astype({'pkt_size' : 'int32', 'pict_type' : 'object', 'coded_picture_number' : 'int32'})
    probe_filtered.columns = ["size", "type", "coding"]

    return pd.merge(left=stats_filtered, right=probe_filtered, left_index=True, right_index=True)
    
    
    
def GOP_lengths(dataframe):
    gop_lengths = dataframe.loc[dataframe['type'] == 'I']['coding']
    gop_lengths = gop_lengths.to_numpy()
    gop_lengths = np.append(gop_lengths, len(dataframe))

    return np.diff(gop_lengths)