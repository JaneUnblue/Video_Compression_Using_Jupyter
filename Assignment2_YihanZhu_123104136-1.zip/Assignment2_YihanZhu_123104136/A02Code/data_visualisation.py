from matplotlib import pyplot as plt

def visualise_pictures(dataframe, range, property, units='bytes'):
    plt.rcParams["figure.figsize"] = (14, 6)
    plt.rcParams["axes.grid"] = True
    COLOURS = { 'I': 'red', 'P':'green', 'B':'blue'}
    
    (start, end) = range
    plot_data = dataframe[start:end]
    
    plot_data.plot(x ='Number', y=property, kind='bar', color=plot_data['type'].replace(COLOURS), legend=False)
    plt.xlabel('Picture Number (display)')
    plt.ylabel(f'{property} ({units})')
    
    
def visualise_GOPs(dataframe, gop_lengths, number_of_gops=1, fps=25):
    plt.rcParams["figure.figsize"] = (14, 6)
    plt.rcParams["axes.grid"] = True
        
    gop_sizes = []
    for i in range(0, number_of_gops):
        start_gop = 0 if i == 0 else (start_gop + gop_lengths[i - 1])
        end_gop = start_gop + gop_lengths[i]
        gop_sizes.append(sum(dataframe[start_gop:end_gop]['size']))
    
    plt.bar(x=range(0, number_of_gops, 1), height=gop_sizes)
    
    for i, v in enumerate(gop_sizes):
        plt.text(i - 0.4, v * 1.05, str(round(v * 8 / (gop_lengths[i] / fps) / 1e6, 2)) + " Mbps", color='black')
        plt.text(i - 0.4, v, str(gop_lengths[i]) + "  Pictures", color='black')
        
    plt.xlabel('GOP Number')
    plt.ylabel('Size (bytes)')
    
    
def visualise_GOP_quality(dataframe, gop_lengths, number_of_gops = 1, metric="PSNR"):
    plt.rcParams["figure.figsize"] = (14, 6)
    plt.rcParams["axes.grid"] = True
        
    gop_quality = []
    for i in range(0, number_of_gops):
        start_gop = 0 if i == 0 else (start_gop + gop_lengths[i - 1])
        end_gop = start_gop + gop_lengths[i]
        gop_quality.append(dataframe[start_gop:end_gop][metric])
    
    plt.boxplot(gop_quality)
        
    plt.xlabel('GOP Number')
    plt.ylabel(metric)