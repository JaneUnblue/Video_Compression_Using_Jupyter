#!/bin/sh
#ffmpeg -hide_banner -i $2 -i $1 -lavfi "[0:v][1:v]ssim=ssim.log;[0:v][1:v]psnr=psnr.log" -f null -

ffmpeg -hide_banner -i $2 -i $1 -lavfi libvmaf='log_fmt=json:log_path='$4':feature=name=psnr_hvs|name=float_ssim' -f null -
ffprobe -hide_banner -v quiet -print_format json -show_frames $2 > $3
